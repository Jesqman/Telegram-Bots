import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from moviepy.editor import VideoFileClip, TextClip, CompositeVideoClip
from typing import List, Dict, Tuple
import speech_recognition as sr
from config import Config

class SubtitleGenerator:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        
    async def extract_audio_text(self, video_path: str, language: str = 'ru') -> List[Dict]:
        """Извлечение текста из видео"""
        video = VideoFileClip(video_path)
        audio = video.audio
        
        # Временно сохраняем аудио
        temp_audio = "temp_audio.wav"
        audio.write_audiofile(temp_audio, verbose=False, logger=None)
        
        # Распознаем речь
        with sr.AudioFile(temp_audio) as source:
            audio_data = self.recognizer.record(source)
            
        try:
            # Используем Google Speech Recognition
            lang_code = 'ru-RU' if language == 'ru' else 'en-US'
            text = self.recognizer.recognize_google(audio_data, language=lang_code)
            
            # Простое разделение на субтитры (можно улучшить)
            words = text.split()
            subtitles = []
            words_per_subtitle = 5
            duration = video.duration
            
            for i in range(0, len(words), words_per_subtitle):
                subtitle_words = words[i:i+words_per_subtitle]
                start_time = (i / len(words)) * duration
                end_time = ((i + words_per_subtitle) / len(words)) * duration
                
                subtitles.append({
                    'text': ' '.join(subtitle_words),
                    'start': start_time,
                    'end': end_time
                })
                
            return subtitles
            
        except sr.UnknownValueError:
            return []
        except sr.RequestError as e:
            return []
        finally:
            import os
            if os.path.exists(temp_audio):
                os.remove(temp_audio)
    
    async def add_subtitles_to_video(
        self, 
        video_path: str, 
        subtitles: List[Dict], 
        style: str = 'classic',
        output_path: str = None
    ) -> str:
        """Добавление субтитров к видео"""
        if not output_path:
            output_path = video_path.replace('.mp4', '_subtitled.mp4')
            
        video = VideoFileClip(video_path)
        style_config = Config.SUBTITLE_STYLES.get(style, Config.SUBTITLE_STYLES['classic'])
        
        # Создаем текстовые клипы для каждого субтитра
        subtitle_clips = []
        
        for subtitle in subtitles:
            txt_clip = TextClip(
                subtitle['text'],
                fontsize=style_config['size'],
                color=style_config['color'],
                font=style_config.get('font', 'Arial'),
                stroke_color=style_config.get('stroke_color'),
                stroke_width=style_config.get('stroke_width', 0) if style_config.get('stroke') else 0,
                bg_color=style_config.get('bg_color'),
                size=(video.w * 0.9, None),
                method='caption',
                align='center'
            )
            
            txt_clip = txt_clip.set_position(('center', 'bottom')).set_start(subtitle['start']).set_duration(subtitle['end'] - subtitle['start'])
            subtitle_clips.append(txt_clip)
        
        # Композируем видео с субтитрами
        final_video = CompositeVideoClip([video] + subtitle_clips)
        final_video.write_videofile(output_path, codec='libx264', audio_codec='aac')
        
        return output_path
import aiohttp
import json
from typing import Dict, Any
from config import Config

class GeminiAPI:
    def __init__(self):
        self.api_key = Config.GEMINI_API_KEY
        self.base_url = Config.GEMINI_API_URL
        
    async def generate_scenario(self, prompt: str, language: str = 'ru') -> Dict[str, Any]:
        """Генерация сценария для видео"""
        
        system_prompt = {
            'ru': """Ты профессиональный сценарист для коротких видео. 
                     Создай увлекательный сценарий для видео длительностью 30-60 секунд.
                     Включи: хук (первые 3 секунды), основную часть, призыв к действию.
                     Формат ответа: JSON с полями hook, main, cta, duration_seconds""",
            'en': """You are a professional scriptwriter for short videos.
                     Create an engaging script for a 30-60 second video.
                     Include: hook (first 3 seconds), main content, call to action.
                     Response format: JSON with fields hook, main, cta, duration_seconds"""
        }
        
        headers = {
            'Content-Type': 'application/json',
        }
        
        data = {
            "contents": [{
                "parts": [{
                    "text": f"{system_prompt[language]}\n\nТема: {prompt}"
                }]
            }],
            "generationConfig": {
                "temperature": 0.7,
                "topK": 1,
                "topP": 1,
                "maxOutputTokens": 2048,
            }
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.base_url}?key={self.api_key}",
                headers=headers,
                json=data
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    try:
                        content = result['candidates'][0]['content']['parts'][0]['text']
                        # Парсим JSON из ответа
                        json_start = content.find('{')
                        json_end = content.rfind('}') + 1
                        scenario_data = json.loads(content[json_start:json_end])
                        return scenario_data
                    except:
                        return {
                            "error": "Failed to parse scenario",
                            "raw_response": result
                        }
                else:
                    return {"error": f"API error: {response.status}"}
from sqlalchemy import Column, Integer, String, DateTime, Boolean, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True, nullable=False)
    username = Column(String)
    language = Column(String, default='ru')
    tariff = Column(String, default='free')
    tariff_expires = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    videos = relationship("Video", back_populates="user")
    scenarios = relationship("Scenario", back_populates="user")

class Video(Base):
    __tablename__ = 'videos'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    file_id = Column(String)
    subtitle_style = Column(String)
    status = Column(String, default='processing')
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="videos")

class Scenario(Base):
    __tablename__ = 'scenarios'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    prompt = Column(String)
    content = Column(JSON)
    language = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="scenarios")
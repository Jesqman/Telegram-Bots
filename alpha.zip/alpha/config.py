import os
from typing import Dict, Any

class Config:
    # Bot settings
    BOT_TOKEN = "8000637220:AAG2iyq60w6ShxKVG0JMFyVdTsv6i5vAmc0"
    CRYPTO_BOT_TOKEN = "468182:AAYzT0VNrtt7uiPDwfgXIFsS57nor92lOmv"
    
    # Gemini API
    GEMINI_API_KEY = "AIzaSyBhVkgxRuMXn-JI3sai0-Q0sPw7UsZNYUI"
    GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent"
    
    # Database
    DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://user:password@localhost/toyshorts")
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
    
    # Pricing (в рублях)
    TARIFFS = {
        "start": {
            "price": 299,
            "name": {"ru": "Старт", "en": "Start"},
            "limits": {
                "videos_per_month": 10,
                "scenario_generations": 20,
                "subtitle_styles": 3
            }
        },
        "standard": {
            "price": 799,
            "name": {"ru": "Стандарт", "en": "Standard"},
            "limits": {
                "videos_per_month": 50,
                "scenario_generations": 100,
                "subtitle_styles": 10
            }
        },
        "pro": {
            "price": 1999,
            "name": {"ru": "Про", "en": "Pro"},
            "limits": {
                "videos_per_month": -1,  # unlimited
                "scenario_generations": -1,
                "subtitle_styles": -1
            }
        }
    }
    
    # Subtitle styles
    SUBTITLE_STYLES = {
        "classic": {
            "font": "Arial",
            "size": 24,
            "color": "white",
            "bg_color": "black",
            "bg_opacity": 0.7
        },
        "modern": {
            "font": "Montserrat",
            "size": 28,
            "color": "white",
            "bg_color": None,
            "stroke": True,
            "stroke_color": "black",
            "stroke_width": 2
        },
        "colorful": {
            "font": "Comic Sans MS",
            "size": 26,
            "color": "yellow",
            "bg_color": "purple",
            "bg_opacity": 0.8
        }
    }